 public class BasicTask extends Task {
    public BasicTask(String name, String description, String username) {
        super(name, description, username);
    }
}
